<?php
/**
* @version      5.0.1 28.05.2022
* @author       MAXXmarketing GmbH
* @package      Jshopping
* @copyright    Copyright (C) 2010 webdesigner-profi.de. All rights reserved.
* @license      GNU/GPL
*/

defined('_JEXEC') or die('Restricted access');
error_reporting(error_reporting() & ~E_NOTICE);

if (!file_exists(JPATH_SITE.'/components/com_jshopping/bootstrap.php')){
    \JSError::raiseError(500,"Please install component \"joomshopping\"");
} 

$display_fileters = 0;
$input = \JFactory::getApplication()->input;
$controller = $input->get("controller");
if (!$controller) $controller = $input->get("view");

if ($controller=="category" && $input->get("category_id")) $display_fileters = 1;
if ($controller=="manufacturer" && $input->get("manufacturer_id")) $display_fileters = 1;
if (!$display_fileters) return "";

require_once (JPATH_SITE.'/components/com_jshopping/bootstrap.php');
\JSFactory::loadCssFiles();
\JSFactory::loadLanguageFile();
$jshopConfig = \JSFactory::getConfig();
$mainframe = \JFactory::getApplication(); 
$show_manufacturers = $params->get('show_manufacturers');
$show_categorys = $params->get('show_categorys');
$show_prices = $params->get('show_prices');
$show_characteristics = $params->get('show_characteristics');

$category_id = $input->get('category_id');
$manufacturer_id = $input->get('manufacturer_id');

$contextfilter = "";
if ($controller=="category"){
    $contextfilter = "jshoping.list.front.product.cat.".$category_id;
}
if ($controller=="manufacturer"){
    $contextfilter = "jshoping.list.front.product.manf.".$manufacturer_id;
}

if ($category_id && $show_manufacturers){
    $category = \JSFactory::getTable('category', 'jshop');
    $category->load($category_id);
    
    $manufacturers = $mainframe->getUserStateFromRequest( $contextfilter.'manufacturers', 'manufacturers', array());
    $manufacturers = \JSHelper::filterAllowValue($manufacturers, "int+");    
    
    $filter_manufactures = $category->getManufacturers();
}

if ($manufacturer_id && $show_categorys){
    $manufacturer = \JSFactory::getTable('manufacturer', 'jshop');        
    $manufacturer->load($manufacturer_id);
    
    $categorys = $mainframe->getUserStateFromRequest( $contextfilter.'categorys', 'categorys', array());
    $categorys = \JSHelper::filterAllowValue($categorys, "int+");
    
    $filter_categorys = $manufacturer->getCategorys();
}

if ($show_prices){
    $fprice_from = $mainframe->getUserStateFromRequest( $contextfilter.'fprice_from', 'fprice_from');
    $fprice_from = \JSHelper::saveAsPrice($fprice_from);
    $fprice_to = $mainframe->getUserStateFromRequest( $contextfilter.'fprice_to', 'fprice_to');
    $fprice_to = \JSHelper::saveAsPrice($fprice_to);
}

if ($show_characteristics && $jshopConfig->admin_show_product_extra_field){
    $characteristic_fields = \JSFactory::getAllProductExtraField();
    $characteristic_fieldvalues = \JSFactory::getAllProductExtraFieldValueDetail();
    $characteristic_displayfields = \JSFactory::getDisplayFilterExtraFieldForCategory($category_id);		
    $extra_fields_active = $mainframe->getUserStateFromRequest($contextfilter.'extra_fields', 'extra_fields', array());
    $extra_fields_active = \JSHelper::filterAllowValue($extra_fields_active, "array_int_k_v+");        
}
    
require(JModuleHelper::getLayoutPath('mod_jshopping_filters'));        
?>